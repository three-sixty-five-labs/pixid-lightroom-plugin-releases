--[[----------------------------------------------------------------------------

AutoExportManager.lua  
EXACT working simple version - no additional features

------------------------------------------------------------------------------]]

local LrDialogs = import 'LrDialogs'
local LrView = import 'LrView'
local LrBinding = import 'LrBinding'
local LrFunctionContext = import 'LrFunctionContext'
local LrTasks = import 'LrTasks'
local LrApplication = import 'LrApplication'
local LrColor = import 'LrColor'
local LrLogger = import 'LrLogger'
local LrPrefs = import 'LrPrefs'

-- Import our modules
local CatalogMonitor = require 'CatalogMonitor'
local PhotoProcessor = require 'PhotoProcessor'
local Settings = require 'Settings'
local Utils = require 'Utils'

-- Simple dual language helper
local function L(en, th)
	return en .. " / " .. th
end

-- Get version info from Info.lua
local Info = require 'Info'
local version = Info.VERSION or { major=1, minor=0, revision=0, build=20250808 }
local versionString = string.format("v%d.%d.%d (build %d)", 
	version.major, version.minor, version.revision, version.build)

local myLogger = LrLogger('AutoExportManager')
myLogger:enable('print')

-- Global state for continuous processing
if not _G.pixidAutoExportState then
	_G.pixidAutoExportState = {
		isRunning = false,
		settings = {},
		stats = {
			startTime = nil,
			photosProcessed = 0,
			lastScanTime = 0,
		}
	}
else
	-- Check if a process is actually still running by looking at lastScanTime
	-- If lastScanTime is recent (within last 60 seconds), process is likely still running
	local timeSinceLastScan = os.time() - (_G.pixidAutoExportState.stats.lastScanTime or 0)
	
	if _G.pixidAutoExportState.isRunning and timeSinceLastScan > 60 then
		-- Process was marked as running but hasn't scanned in over 60 seconds - likely dead
		myLogger:trace("[STATE] Process appears dead (no scan for " .. timeSinceLastScan .. " seconds), resetting state")
		_G.pixidAutoExportState.isRunning = false
	elseif _G.pixidAutoExportState.isRunning then
		myLogger:trace("[STATE] Active process detected (last scan " .. timeSinceLastScan .. " seconds ago)")
	end
end

-- Enhanced importFolder function with batch processing
local function importFolder(catalog, outputFolder, photoSize, ftpInfo, extra, folder)
	myLogger:trace("[IMPORT] Start Import")
	
	-- Get photos from the specific folder, exactly like original plugin
	local photos = folder:getPhotos()
	local photosToExport = {}

	for _, photo in pairs(photos) do
		local rating = photo:getRawMetadata("rating") or 0
		if rating == 0 then	
			table.insert(photosToExport, photo)
		end
	end

	local result = {
		found = #photosToExport,
		processed = 0,
		ftpErrors = 0
	}

	myLogger:trace("[IMPORT] Found " .. #photosToExport .. " photos with rating=0 to process")

	if #photosToExport > 0 then
		-- Get batch settings from global state or use defaults
		local state = _G.pixidAutoExportState
		local batchSize = (state and state.settings and state.settings.batchSize) or 5
		local showDetailedProgress = (state and state.settings and state.settings.showDetailedProgress) or false
		
		-- Enhanced debug logging
		myLogger:trace("[IMPORT] Global state exists: " .. tostring(state ~= nil))
		if state then
			myLogger:trace("[IMPORT] Settings exist: " .. tostring(state.settings ~= nil))
			if state.settings then
				myLogger:trace("[IMPORT] All settings: batchSize=" .. tostring(state.settings.batchSize) .. 
							 ", showDetailedProgress=" .. tostring(state.settings.showDetailedProgress))
			end
		end
		myLogger:trace("[IMPORT] Final values - batchSize: " .. batchSize .. ", showDetailedProgress: " .. tostring(showDetailedProgress))
		
		-- Process only ONE batch per scan cycle to avoid blocking tethering
		local photosInThisBatch = math.min(batchSize, #photosToExport)
		local batch = {}
		
		for i = 1, photosInThisBatch do
			table.insert(batch, photosToExport[i])
		end
		
		local remainingPhotos = #photosToExport - photosInThisBatch
		
		-- Always show bezel with debug info
		local bezelMessage
		if showDetailedProgress then
			bezelMessage = "Processing " .. photosInThisBatch .. " photos (" .. remainingPhotos .. " remaining)"
		else
			bezelMessage = photosInThisBatch .. " photos to process"
		end
		
		myLogger:trace("[IMPORT] About to show bezel: '" .. bezelMessage .. "'")
		LrDialogs.showBezel(bezelMessage)
		myLogger:trace("[IMPORT] Bezel shown successfully")
		
		myLogger:trace("[IMPORT] Processing " .. photosInThisBatch .. " photos this cycle (" .. remainingPhotos .. " remaining for next cycles)")
		
		-- Process this batch directly
		local batchStartTime = os.time()
		
		myLogger:trace("[IMPORT] Starting batch processing at " .. os.date("%H:%M:%S", batchStartTime) .. 
					 " - batch " .. photosInThisBatch .. "/" .. #photosToExport .. " photos")
		
		-- Process the batch directly
		local processResult = PhotoProcessor.processPhotos(batch, outputFolder, photoSize, ftpInfo, extra)
		
		-- Handle results
		local batchEndTime = os.time()
		local batchDuration = batchEndTime - batchStartTime
		
		if processResult then
			result.processed = processResult.processed or 0
			result.ftpErrors = processResult.ftpErrors or 0
			myLogger:trace("[IMPORT] Batch completed successfully in " .. batchDuration .. "s: " .. 
						 result.processed .. " processed, " .. result.ftpErrors .. " FTP errors")
		else
			-- Processing failed or was cancelled
			result.processed = 0
			result.ftpErrors = 0
			myLogger:trace("[IMPORT] Batch processing failed or was cancelled")
		end
		
		-- Update statistics if we're in continuous processing mode
		if state and state.isRunning and processResult and processResult.processed then
			state.stats.photosProcessed = state.stats.photosProcessed + processResult.processed
		end
		
		myLogger:trace("[IMPORT] Completed batch: " .. result.processed .. " processed, " .. result.ftpErrors .. " FTP errors")
	else
		myLogger:trace("[IMPORT] nothing to process")
		-- Always show bezel to let user know the process is running and checking
		if _G.pixidAutoExportState.isRunning then
			LrDialogs.showBezel("Auto-process running - no new photos found")
		else
			LrDialogs.showBezel("No photos to process")
		end
	end

	myLogger:trace("[IMPORT] finish import")
	return result
end

-- Main dialog function
local function createMainDialog()
	-- Load folders in async task first, then show dialog
	LrTasks.startAsyncTask(function()
		local LrCatalog = LrApplication.activeCatalog()
		local catalogFolders = LrCatalog:getFolders()
		local folderCombo = {}
		local folderIndex = {}
		
		-- Build simple folder list (just names, like working plugin)
		for i, folder in pairs(catalogFolders) do
			folderCombo[i] = folder:getName()
			folderIndex[folder:getName()] = folder
		end
		
		-- Now create the dialog with the loaded folders
		LrFunctionContext.callWithContext("AutoExportManager", function(context)
			-- Log current state when dialog opens
			myLogger:trace("[DIALOG] Opening dialog - isRunning: " .. tostring(_G.pixidAutoExportState.isRunning) .. 
						 ", lastScan: " .. (_G.pixidAutoExportState.stats.lastScanTime or 0))
			
			-- Load saved settings FIRST
			local currentSettings = Settings.load()
		
		
		-- Create property table and initialize it BEFORE creating any UI components
		local props = LrBinding.makePropertyTable(context)
		
		-- Initialize properties
		props.outputFolder = currentSettings.outputFolder or Utils.getDefaultPicturesDir()
		props.photoSize = currentSettings.photoSize or "2000"
		props.scanInterval = tostring(currentSettings.scanInterval or 30)
		props.applyPresets = currentSettings.applyPresets or false
		props.useFileSizeLimit = currentSettings.useFileSizeLimit or false
		props.fileSizeLimit = tostring(currentSettings.fileSizeLimitKB or 750)
		props.ftpEnabled = currentSettings.ftpEnabled or false
		props.ftpUsername = currentSettings.ftpUsername or ""
		props.ftpPassword = currentSettings.ftpPassword or ""
		
		-- Advanced reliability settings
		props.batchSize = tostring(currentSettings.batchSize or 5)
		
		
		
		
		-- NOW create the view factory AFTER props are initialized
		local f = LrView.osFactory()
		
		-- UI Components (enhanced)
		local outputFolderField = f:static_text {
			title = props.outputFolder,
			width = 400,
			truncate = 'head',
			font = "<system>",
			text_color = LrColor(0.2, 0.2, 0.2),
			alignment = "left",
		}
		
		local selectFolderButton = f:push_button {
			title = "Browse...",
			action = function()
				local result = LrDialogs.runOpenPanel {
					title = "Select Output Folder",
					prompt = "Choose folder for exported photos",
					canChooseFiles = false,
					canChooseDirectories = true,
					allowsMultipleSelection = false,
				}
				if result and #result > 0 then
					props.outputFolder = result[1]
					outputFolderField.title = result[1]
				end
			end,
		}
		
		-- Photo size options - simple approach
		local sizeItems = {"1500", "2000", "3000", "4000", "original"}
		
		-- Create a reference to store the current size selection
		local currentPhotoSize = props.photoSize
		
		local sizePopup = f:combo_box {
			items = sizeItems,
			value = currentPhotoSize,
			width = 140,
			immediate = true,
		}
		
		
		local applyPresetsCheckbox = f:checkbox {
			title = "Apply presets from Favorites folder",
			value = props.applyPresets,
		}
		
		local useFileSizeLimitCheckbox = f:checkbox {
			title = "Limit JPEG file size to",
			value = props.useFileSizeLimit,
		}
		
		local fileSizeLimitField = f:edit_field {
			value = props.fileSizeLimit,
			width = 100,
			immediate = true,
		}
		
		local ftpEnabledCheckbox = f:checkbox {
			title = "Enable FTP upload to pixid",
			value = props.ftpEnabled,
		}
		
		local ftpUsernameField = f:edit_field {
			value = props.ftpUsername,
			width = 180,
			placeholder_text = "Enter your pixid username",
		}
		
		local ftpPasswordField = f:password_field {
			value = props.ftpPassword,
			width = 180,
			placeholder_text = "Enter your pixid password",
		}
		
		local scanIntervalField = f:edit_field {
			value = props.scanInterval,
			width = 60,
			precision = 0,
		}
		
		-- Advanced reliability settings UI controls
		local batchSizeField = f:edit_field {
			value = props.batchSize,
			width = 60,
			precision = 0,
		}
		
		
		
		
		-- Status display
		local statusText = f:static_text {
			title = _G.pixidAutoExportState.isRunning and "Auto-processing is running..." or "Ready to start",
			font = "<system>",
			text_color = _G.pixidAutoExportState.isRunning and LrColor(0.0, 0.6, 0.0) or LrColor(0.5, 0.5, 0.5),
			width = 400,
		}
		
		-- Initialize folder selection - use first actual folder as default
		props.selectedFolderName = currentSettings.selectedFolderName or folderCombo[1]
		
		-- Folder dropdown
		local folderField = f:combo_box {
			items = folderCombo,
			value = props.selectedFolderName,
			width = 300,
			immediate = true,
		}
		
		-- No more extractSizeValue helper needed - using direct value binding
		
		-- Helper function to gather current settings
		local function gatherCurrentSettings()
			local settings = {
				outputFolder = props.outputFolder,
				photoSize = sizePopup.value, -- Read directly from dropdown instead of props
				scanInterval = tonumber(scanIntervalField.value) or 30,
				applyPresets = applyPresetsCheckbox.value,
				useFileSizeLimit = useFileSizeLimitCheckbox.value,
				fileSizeLimitKB = tonumber(fileSizeLimitField.value) or 750,
				ftpEnabled = ftpEnabledCheckbox.value,
				ftpUsername = ftpUsernameField.value,
				ftpPassword = ftpPasswordField.value,
				selectedFolderName = folderField.value,
				
				-- Advanced reliability settings (always enabled)
				batchSize = tonumber(batchSizeField.value) or 5,
				showDetailedProgress = true, -- Always show detailed progress
			}
			
			-- Debug: Log the settings being gathered
			myLogger:trace("[SETTINGS] Gathering settings - batchSize: " .. tostring(settings.batchSize) .. 
						 ", showDetailedProgress: " .. tostring(settings.showDetailedProgress) .. " (always enabled)")
			
			return settings
		end
		
		-- Helper function to format elapsed time
		local function formatElapsedTime(startTime)
			if not startTime then return "0:00" end
			local elapsed = os.time() - startTime
			local minutes = math.floor(elapsed / 60)
			local seconds = elapsed % 60
			return string.format("%d:%02d", minutes, seconds)
		end
		
		-- Helper function to update status display
		local function updateStatusDisplay()
			if not statusText then return end
			
			if _G.pixidAutoExportState.isRunning then
				local stats = _G.pixidAutoExportState.stats
				local elapsed = formatElapsedTime(stats.startTime)
				local lastScan = stats.lastScanTime > 0 and os.date("%H:%M:%S", stats.lastScanTime) or "Never"
				
				statusText.title = string.format("Running (%s) | Processed: %d photos | Last scan: %s", 
					elapsed, stats.photosProcessed, lastScan)
				statusText.text_color = LrColor(0.0, 0.6, 0.0)
			else
				statusText.title = "Ready to start auto-processing"
				statusText.text_color = LrColor(0.5, 0.5, 0.5)
			end
		end
		
		-- Process Once button - with status updates
		local function processOnce()
			local catalog = LrApplication.activeCatalog()
			
			-- Validate output folder
			if not props.outputFolder or props.outputFolder == "" then
				LrDialogs.message("Error", "Please select an output folder", "warning")
				return
			end
			
			-- Update status to show processing
			statusText.title = "Processing photos..."
			statusText.text_color = LrColor(0.8, 0.6, 0.0) -- Orange for processing
			
			-- Build parameters exactly like working plugin
			local ftpInfo = {}
			ftpInfo['isEnabled'] = ftpEnabledCheckbox.value
			ftpInfo['ftpUsername'] = ftpUsernameField.value
			ftpInfo['ftpPassword'] = ftpPasswordField.value
			
			local extra = {}
			extra['presetsInFavoriteIsApplied'] = applyPresetsCheckbox.value
			extra['useFileSizeLimit'] = useFileSizeLimitCheckbox.value
			extra['fileSizeLimit'] = tostring(tonumber(fileSizeLimitField.value) or 750)
			
			-- Get selected folder
			local selectedFolder = folderIndex[folderField.value]
			
			LrTasks.startAsyncTask(function()
				local startTime = os.time()
				
				local result = importFolder(catalog, props.outputFolder, props.photoSize, ftpInfo, extra, selectedFolder)
				
				local endTime = os.time()
				local duration = endTime - startTime
				
				-- Update status to show completion with details
				local statusMsg = string.format("Completed: %d photos processed", result.processed)
				if result.ftpErrors > 0 then
					statusMsg = statusMsg .. string.format(" (%d FTP errors)", result.ftpErrors)
					statusText.text_color = LrColor(0.8, 0.6, 0.0) -- Orange if FTP errors
				else
					statusText.text_color = LrColor(0.0, 0.6, 0.0) -- Green for full success
				end
				statusText.title = statusMsg

				if LrTasks.canYield() then
					LrTasks.yield()
				end
			end)
		end
		
		-- Start continuous processing
		local function startContinuousProcessing()
			if _G.pixidAutoExportState.isRunning then
				LrDialogs.message("Already Running", "Auto-processing is already running.", "info")
				return
			end
			
			-- Validate output folder
			if not props.outputFolder or props.outputFolder == "" then
				LrDialogs.message("Error", "Please select an output folder", "warning")
				return
			end
			
			-- Gather settings for continuous processing
			local currentSettings = gatherCurrentSettings()
			
			-- Update global state
			_G.pixidAutoExportState.isRunning = true
			_G.pixidAutoExportState.settings = currentSettings
			_G.pixidAutoExportState.stats.startTime = os.time()
			_G.pixidAutoExportState.stats.photosProcessed = 0
			
			-- Debug: Verify settings are stored correctly in global state
			myLogger:trace("[AUTO] Settings stored in global state - showDetailedProgress: " .. 
						 tostring(_G.pixidAutoExportState.settings.showDetailedProgress))
			
			-- Save settings
			Settings.save(currentSettings)
			
			myLogger:trace("[AUTO] Starting continuous processing with " .. currentSettings.scanInterval .. " second wait between batches")
			
			-- Start the background processing loop
			LrTasks.startAsyncTask(function()
				local catalog = LrApplication.activeCatalog()
				
				-- Get settings from global state since currentSettings is not in this scope
				local settings = _G.pixidAutoExportState.settings
				
				while _G.pixidAutoExportState.isRunning do
					myLogger:trace("[AUTO] Scanning for new photos...")
					
					-- Update heartbeat at start of each cycle
					_G.pixidAutoExportState.stats.lastScanTime = os.time()
					
					-- Build parameters exactly like working plugin
					local ftpInfo = {}
					ftpInfo['isEnabled'] = settings.ftpEnabled
					ftpInfo['ftpUsername'] = settings.ftpUsername
					ftpInfo['ftpPassword'] = settings.ftpPassword
					
					local extra = {}
					extra['presetsInFavoriteIsApplied'] = settings.applyPresets
					extra['useFileSizeLimit'] = settings.useFileSizeLimit
					extra['fileSizeLimit'] = tostring(settings.fileSizeLimitKB)
					
					-- Get selected folder for continuous processing
					local selectedFolder = nil
					local allFolders = catalog:getFolders()
					for _, folder in pairs(allFolders) do
						if folder:getName() == settings.selectedFolderName then
							selectedFolder = folder
							break
						end
					end
					
					-- Process photos using existing importFolder function if folder found
					if selectedFolder then
						importFolder(catalog, settings.outputFolder, settings.photoSize, ftpInfo, extra, selectedFolder)
					else
						myLogger:trace("[AUTO] Selected folder not found: " .. (settings.selectedFolderName or "nil"))
					end
					
					-- Update heartbeat after processing  
					_G.pixidAutoExportState.stats.lastScanTime = os.time()
					
					-- Show initial wait message if we're going to wait
					if settings.scanInterval > 0 then
						LrDialogs.showBezel("Auto-process waiting " .. settings.scanInterval .. "s until next scan")
					end
					
					-- Wait between batches, updating heartbeat and showing progress
					for i = 1, settings.scanInterval do
						if not _G.pixidAutoExportState.isRunning then break end
						
						-- Update heartbeat and show bezel every 5 seconds during wait
						if i % 5 == 0 then
							_G.pixidAutoExportState.stats.lastScanTime = os.time()
							local remaining = settings.scanInterval - i
							if remaining > 0 then
								LrDialogs.showBezel("Auto-process waiting... " .. remaining .. "s until next scan")
								myLogger:trace("[AUTO] Heartbeat update during wait - " .. remaining .. "s remaining")
							end
						end
						
						LrTasks.sleep(1) -- Sleep 1 second at a time for responsive stopping
					end
				end
				
				myLogger:trace("[AUTO] Continuous processing stopped")
			end)
			
			LrDialogs.showBezel("Auto-processing started")
			updateStatusDisplay()
		end
		
		-- Stop continuous processing
		local function stopContinuousProcessing()
			myLogger:trace("[STOP] Stop button clicked - isRunning: " .. tostring(_G.pixidAutoExportState.isRunning))
			
			if not _G.pixidAutoExportState.isRunning then
				-- Check if there might be a zombie process
				local lastScan = _G.pixidAutoExportState.stats.lastScanTime or 0
				local timeSinceLastScan = os.time() - lastScan
				myLogger:trace("[STOP] Not marked as running. Last scan was " .. timeSinceLastScan .. " seconds ago")
				
				LrDialogs.message("Not Running", "Auto-processing is not currently running.", "info")
				return
			end
			
			_G.pixidAutoExportState.isRunning = false
			myLogger:trace("[AUTO] Stopping continuous processing")
			LrDialogs.showBezel("Auto-processing stopped")
			updateStatusDisplay()
		end
		
		-- Main UI Layout (compact)
		local contents = f:column {
			spacing = f:control_spacing() / 2, -- Reduce spacing by half
			margin = 8, -- Reduce margin
			
			-- Header Section
			f:row {
				fill_horizontal = 1,
				f:column {
					fill_horizontal = 1,
					spacing = f:control_spacing(),
					f:row {
						fill_horizontal = 1,
						f:column {
							fill_horizontal = 1,
							f:static_text {
								title = "pixid Auto Export",
								font = "<system/bold>",
								text_color = LrColor(0.2, 0.4, 0.8),
								alignment = "left",
							},
						},
						f:spacer { fill_horizontal = 1 },
						f:static_text {
							title = versionString,
							font = "<system/small>",
							text_color = LrColor(0.6, 0.6, 0.6),
							alignment = "right",
						},
					},
				},
			},
			
			f:spacer { height = 3 },
			
			-- Folder Selection Group  
			f:group_box {
				title = "Session Selection",
				fill_horizontal = 1,
				f:column {
					spacing = f:control_spacing(),
					margin = 6,
					
					f:row {
						spacing = f:control_spacing(),
						f:static_text { 
							title = "Process session:",
							width = 100,
							font = "<system>",
							text_color = LrColor(0.3, 0.3, 0.3),
						},
						folderField,
						f:spacer { fill_horizontal = 1 },
					},
				},
			},
			
			f:spacer { height = 3 },
			
			-- Export Settings Group
			f:group_box {
				title = "Export Settings",
				fill_horizontal = 1,
				f:column {
					spacing = f:control_spacing(),
					margin = 6,
					
					-- Output folder section
					f:static_text {
						title = "Output Folder",
						font = "<system>",
						text_color = LrColor(0.3, 0.3, 0.3),
					},
					
					f:row {
						spacing = f:control_spacing(),
						f:column {
							fill_horizontal = 1,
							outputFolderField,
						},
						selectFolderButton,
					},
					
					f:spacer { height = 2 },
					
					-- Photo size section
					f:row {
						spacing = f:control_spacing(),
						f:static_text { 
							title = "Photo Size:",
							width = 120,
							font = "<system>",
							text_color = LrColor(0.3, 0.3, 0.3),
						},
						sizePopup,
						f:static_text { 
							title = "pixels",
							font = "<system>",
							text_color = LrColor(0.5, 0.5, 0.5),
						},
						f:spacer { fill_horizontal = 1 },
					},
				},
			},
			
			f:spacer { height = 3 },
			
			-- Processing Options Group
			f:group_box {
				title = "Processing Options",
				fill_horizontal = 1,
				f:column {
					spacing = f:control_spacing(),
					margin = 6,
					
					applyPresetsCheckbox,
					
					f:spacer { height = 2 },
					
					f:row {
						spacing = f:control_spacing(),
						useFileSizeLimitCheckbox,
						fileSizeLimitField,
						f:static_text { 
							title = "KB",
							font = "<system>",
							text_color = LrColor(0.5, 0.5, 0.5),
						},
						f:spacer { fill_horizontal = 1 },
					},
					
					f:spacer { height = 2 },
					
					f:row {
						spacing = f:control_spacing(),
						f:static_text { 
							title = "Wait between batches:",
							width = 140,
							font = "<system>",
							text_color = LrColor(0.3, 0.3, 0.3),
						},
						scanIntervalField,
						f:static_text { 
							title = "seconds",
							font = "<system>",
							text_color = LrColor(0.5, 0.5, 0.5),
						},
						f:spacer { fill_horizontal = 1 },
					},
					
					f:spacer { height = 2 },
					
					f:row {
						spacing = f:control_spacing(),
						f:static_text { 
							title = "Batch size:",
							width = 140,
							font = "<system>",
							text_color = LrColor(0.3, 0.3, 0.3),
						},
						batchSizeField,
						f:static_text { 
							title = "photos per batch",
							font = "<system>",
							text_color = LrColor(0.5, 0.5, 0.5),
						},
						f:spacer { fill_horizontal = 1 },
					},
				},
			},
			
			f:spacer { height = 3 },
			
			-- FTP Upload Group
			f:group_box {
				title = "FTP Upload (Optional)",
				fill_horizontal = 1,
				f:column {
					spacing = f:control_spacing(),
					margin = 6,
					
					ftpEnabledCheckbox,
					
					f:spacer { height = 3 },
					
					-- FTP credentials (with conditional visibility)
					f:column {
						spacing = f:control_spacing(),
						
						f:row {
							spacing = f:control_spacing(),
							f:static_text { 
								title = "Username:",
								width = 80,
								font = "<system>",
								text_color = LrColor(0.4, 0.4, 0.4),
							},
							ftpUsernameField,
							f:spacer { fill_horizontal = 1 },
						},
						
						f:row {
							spacing = f:control_spacing(),
							f:static_text { 
								title = "Password:",
								width = 80,
								font = "<system>",
								text_color = LrColor(0.4, 0.4, 0.4),
							},
							ftpPasswordField,
							f:spacer { fill_horizontal = 1 },
						},
					},
				},
			},
			
			f:spacer { height = 4 },
			
			-- Status Section
			f:group_box {
				title = "Status",
				fill_horizontal = 1,
				f:column {
					spacing = f:control_spacing(),
					margin = 6,
					
					statusText,
				},
			},
			
			f:spacer { height = 3 },
			
			-- Action Section
			f:row {
				spacing = f:control_spacing(),
				fill_horizontal = 1,
				f:spacer { fill_horizontal = 1 },
				
				f:push_button {
					title = L("Process Once Now", "ประมวลผลครั้งเดียว"),
					action = processOnce,
				},
				
				f:push_button {
					title = L("Start Auto-Processing", "เริ่มประมวลผลอัตโนมัติ"),
					action = startContinuousProcessing,
				},
				
				f:push_button {
					title = L("Stop Auto-Processing", "หยุดประมวลผลอัตโนมัติ"), 
					action = stopContinuousProcessing,
				},
				
				f:spacer { fill_horizontal = 1 },
			},
			
		}
		
		-- Start background task for real-time status updates
		LrTasks.startAsyncTask(function()
			while true do
				updateStatusDisplay()
				LrTasks.sleep(2) -- Update every 2 seconds
			end
		end)
		
		-- Initial status update
		updateStatusDisplay()
		
		-- Show dialog
		local result = LrDialogs.presentModalDialog {
			title = "pixid Auto Export - " .. versionString,
			contents = contents,
			actionVerb = "Save & Close",
			cancelVerb = "Cancel",
		}
		
		
		-- Auto-save settings when dialog closes
		local currentSettings = gatherCurrentSettings()
		Settings.save(currentSettings)
		end) -- End of function context
	end) -- End of async task
end

-- Start the main dialog
createMainDialog()