--[[----------------------------------------------------------------------------

Info.lua
Plugin manifest for pixid Auto Export - Universal Photo Processing

--------------------------------------------------------------------------------

PIXID AUTO EXPORT PLUGIN
Copyright 2025 365Labs
All Rights Reserved.

Revamped auto-export plugin that provides universal photo detection,
automatic processing, and flexible export workflows for Lightroom.

------------------------------------------------------------------------------]]

return {
	LrSdkVersion = 5.0,
	LrSdkMinimumVersion = 5.0,

	LrToolkitIdentifier = 'org.365labs.pixid.autoexport',
	LrPluginName = "pixid Auto Export",
	
	-- Main menu access point
	LrExportMenuItems = {{
		title = "pixid Auto Export Console",
		file = "AutoExportManager.lua",
	}},

	VERSION = { major=1, minor=0, revision=0, build=20250808 },
}