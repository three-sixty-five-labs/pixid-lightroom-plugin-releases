CatalogMonitor.lua
Universal photo detection system for pixid Auto Export
Provides functions to scan entire catalog for new photos regardless of source:
- Tethered photos
- Auto-import photos
- Manual import photos
Uses rating-based filtering to identify unprocessed photos (rating = 0)
local LrLogger = import 'LrLogger'
local myLogger = LrLogger('CatalogMonitor')
myLogger:enable('print')
local CatalogMonitor = {}
function CatalogMonitor.scanForNewPhotos(catalog, targetFolderParam)
	local targetFolder = nil
	if targetFolderParam and type(targetFolderParam) == "string" then
		myLogger:trace("[MONITOR] Looking for folder by name: " .. targetFolderParam)
		local allFolders = catalog:getFolders()
		local function findFolderByName(folders, name)
			for _, folder in pairs(folders) do
				if folder:getName() == name then
					return folder
				end
				local subfolders = folder:getChildren()
				if subfolders then
					local found = findFolderByName(subfolders, name)
					if found then return found end
				end
			end
			return nil
		end
		targetFolder = findFolderByName(allFolders, targetFolderParam)
		if targetFolder then
			myLogger:trace("[MONITOR] Found folder: " .. targetFolderParam)
		else
			myLogger:trace("[MONITOR] Folder not found: " .. targetFolderParam .. ", scanning entire catalog")
		end
	elseif targetFolderParam then
		targetFolder = targetFolderParam
		myLogger:trace("[MONITOR] Starting folder-specific scan: " .. (targetFolder:getName() or "Unknown"))
	else
		myLogger:trace("[MONITOR] Starting universal catalog scan")
	end
	local allFolders = catalog:getFolders()
	local newPhotos = {}
	local foldersScanned = 0
	local totalPhotosFound = 0
	local function scanFolder(folder, depth)
		depth = depth or 0
		local indentLog = string.rep("  ", depth)
		myLogger:trace(indentLog .. "[MONITOR] Scanning folder: " .. folder:getName())
		local photos = folder:getPhotos()
		local folderNewPhotos = 0
		for _, photo in pairs(photos) do
			local rating = photo:getRawMetadata("rating") or 0
			if rating == 0 then -- Unprocessed photos
				table.insert(newPhotos, photo)
				folderNewPhotos = folderNewPhotos + 1
				totalPhotosFound = totalPhotosFound + 1
			end
		end
		if folderNewPhotos > 0 then
			myLogger:trace(indentLog .. "[MONITOR] Found " .. folderNewPhotos .. " new photos in " .. folder:getName())
		end
		local subfolders = folder:getChildren()
		for _, subfolder in pairs(subfolders) do
			if subfolder:type() == "LrFolder" then -- Only process folder children, not collections
				scanFolder(subfolder, depth + 1)
			end
		end
		foldersScanned = foldersScanned + 1
	end
	if targetFolder then
		scanFolder(targetFolder, 0)
	else
		for _, folder in pairs(allFolders) do
			scanFolder(folder, 0)
		end
	end
	myLogger:trace("[MONITOR] Scan complete - " .. foldersScanned .. " folders scanned, " .. totalPhotosFound .. " new photos found")
	return newPhotos, {
		foldersScanned = foldersScanned,
		photosFound = totalPhotosFound
	}
end
function CatalogMonitor.getPhotosAddedSince(catalog, lastScanTime)
	myLogger:trace("[MONITOR] Scanning for photos added since " .. os.date("%Y-%m-%d %H:%M:%S", lastScanTime))
	local allPhotos = catalog:getAllPhotos()
	local recentPhotos = {}
	local checkedCount = 0
	for _, photo in pairs(allPhotos) do
		checkedCount = checkedCount + 1
		local addedTime = photo:getRawMetadata("dateAdded")
		local rating = photo:getRawMetadata("rating") or 0
		if addedTime and addedTime > lastScanTime and rating == 0 then
			table.insert(recentPhotos, photo)
			myLogger:trace("[MONITOR] Found recent photo: " .. (photo:getFormattedMetadata("fileName") or "unknown"))
		end
		if checkedCount % 100 == 0 then
			local LrTasks = import 'LrTasks'
			if LrTasks.canYield() then
				LrTasks.yield()
			end
		end
	end
	myLogger:trace("[MONITOR] Time-based scan complete - " .. checkedCount .. " photos checked, " .. #recentPhotos .. " recent photos found")
	return recentPhotos
end
function CatalogMonitor.getCatalogStats(catalog)
	myLogger:trace("[MONITOR] Gathering catalog statistics")
	local stats = {
		totalFolders = 0,
		totalPhotos = 0,
		unprocessedPhotos = 0, -- rating = 0
		processedPhotos = 0,   -- rating > 0
		ratingDistribution = {
			[0] = 0, [1] = 0, [2] = 0, [3] = 0, [4] = 0, [5] = 0
		}
	}
	local allFolders = catalog:getFolders()
	local function countFoldersRecursive(folder)
		stats.totalFolders = stats.totalFolders + 1
		local subfolders = folder:getChildren()
		for _, subfolder in pairs(subfolders) do
			if subfolder:type() == "LrFolder" then
				countFoldersRecursive(subfolder)
			end
		end
	end
	for _, folder in pairs(allFolders) do
		countFoldersRecursive(folder)
	end
	local allPhotos = catalog:getAllPhotos()
	for _, photo in pairs(allPhotos) do
		stats.totalPhotos = stats.totalPhotos + 1
		local rating = photo:getRawMetadata("rating") or 0
		stats.ratingDistribution[rating] = (stats.ratingDistribution[rating] or 0) + 1
		if rating == 0 then
			stats.unprocessedPhotos = stats.unprocessedPhotos + 1
		else
			stats.processedPhotos = stats.processedPhotos + 1
		end
	end
	myLogger:trace("[MONITOR] Catalog stats: " .. stats.totalFolders .. " folders, " .. stats.totalPhotos .. " photos (" .. stats.unprocessedPhotos .. " unprocessed)")
	return stats
end
function CatalogMonitor.shouldProcessPhoto(photo)
	local rating = photo:getRawMetadata("rating") or 0
	return rating == 0
end
function CatalogMonitor.getNewPhotosFromFolder(catalog, folderName)
	myLogger:trace("[MONITOR] Scanning specific folder: " .. folderName)
	local allFolders = catalog:getFolders()
	local targetFolder = nil
	local function findFolderByName(folder, name)
		if folder:getName() == name then
			return folder
		end
		local subfolders = folder:getChildren()
		for _, subfolder in pairs(subfolders) do
			if subfolder:type() == "LrFolder" then
				local found = findFolderByName(subfolder, name)
				if found then return found end
			end
		end
		return nil
	end
	for _, folder in pairs(allFolders) do
		targetFolder = findFolderByName(folder, folderName)
		if targetFolder then break end
	end
	if not targetFolder then
		myLogger:trace("[MONITOR] Folder not found: " .. folderName)
		return {}
	end
	local photos = targetFolder:getPhotos()
	local newPhotos = {}
	for _, photo in pairs(photos) do
		if CatalogMonitor.shouldProcessPhoto(photo) then
			table.insert(newPhotos, photo)
		end
	end
	myLogger:trace("[MONITOR] Found " .. #newPhotos .. " new photos in folder: " .. folderName)
	return newPhotos
end
function CatalogMonitor.getAllFoldersForUI(catalog)
	myLogger:trace("[MONITOR] Building folder list for UI")
	local folderList = {}
	local allFolders = catalog:getFolders()
	local function addFolderToList(folder, depth)
		depth = depth or 0
		local indent = string.rep("    ", depth) -- 4 spaces per level
		local folderName = "Unknown"
		local folderPath = ""
		local ok, name = pcall(function() return folder:getName() end)
		if ok and name then
			folderName = name
		end
		local ok2, path = pcall(function() return folder:getPath() end)
		if ok2 and path then
			folderPath = path
		else
			folderPath = folderName
		end
		table.insert(folderList, {
			title = indent .. folderName,
			value = folder,
			path = folderPath,
			depth = depth
		})
		local ok3, subfolders = pcall(function() return folder:getChildren() end)
		if ok3 and subfolders then
			for _, subfolder in pairs(subfolders) do
				local isFolder = false
				local ok4, folderType = pcall(function() return subfolder:type() end)
				if ok4 and folderType == "LrFolder" then
					isFolder = true
				end
				if isFolder then
					addFolderToList(subfolder, depth + 1)
				end
			end
		end
	end
	for _, folder in pairs(allFolders) do
		addFolderToList(folder, 0)
	end
	myLogger:trace("[MONITOR] Found " .. #folderList .. " folders for UI")
	return folderList
end
return CatalogMonitor