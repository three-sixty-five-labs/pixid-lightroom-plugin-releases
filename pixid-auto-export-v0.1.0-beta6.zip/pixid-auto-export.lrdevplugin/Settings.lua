Settings.lua
Configuration persistence for pixid Auto Export
Handles loading, saving, and validation of plugin settings using Lightroom's
preferences system. Provides default values and migration support.
local LrPrefs = import 'LrPrefs'
local LrLogger = import 'LrLogger'
local Utils = require 'Utils'
local myLogger = LrLogger('Settings')
myLogger:enable('print')
local Settings = {}
local PREFS_KEY = "pixidAutoExportSettings"
local VERSION_KEY = "pixidAutoExportVersion"
local CURRENT_VERSION = "1.0.0"
function Settings.getDefaults()
	return {
		outputFolder = Utils.getDefaultPicturesDir(),
		photoSize = "2000",
		jpegQuality = 1.0,
		useFileSizeLimit = false,
		fileSizeLimitKB = 750,
		applyPresets = true,
		presetFolder = "Favorites",
		scanInterval = 30, -- seconds wait between batches
		autoStartOnLightroom = false,
		maxPhotosPerBatch = 10,
		scanMode = "all", -- "all" or "selected"
		selectedFolder = "",
		selectedFolderName = "", -- Will default to first folder
		batchSize = 5,                -- Photos per batch
		showDetailedProgress = true,  -- Always show detailed progress
		ftpEnabled = false,
		ftpUsername = "",
		ftpPassword = "",
		ftpServer = "ftp.pixid.app",
		ftpPort = 21,
		ftpPath = "/",
		deleteAfterUpload = false,
		preserveOriginalName = true,
		logLevel = "info",
		windowPosition = nil,
		lastUsed = os.time(),
	}
end
function Settings.load()
	local prefs = LrPrefs.prefsForPlugin()
	local savedSettings = prefs[PREFS_KEY] or {}
	local savedVersion = prefs[VERSION_KEY] or "0.0.0"
	myLogger:trace("[SETTINGS] Loading settings (version: " .. savedVersion .. ")")
	local settings = Utils.mergeTables(Settings.getDefaults(), savedSettings)
	settings = Settings.migrateSettings(settings, savedVersion)
	settings = Settings.validateAndSanitize(settings)
	myLogger:trace("[SETTINGS] Settings loaded successfully")
	return settings
end
function Settings.save(settings)
	if not settings then
		myLogger:trace("[SETTINGS] No settings to save")
		return false
	end
	local validatedSettings = Settings.validateAndSanitize(settings)
	validatedSettings.lastUsed = os.time()
	local prefs = LrPrefs.prefsForPlugin()
	prefs[PREFS_KEY] = validatedSettings
	prefs[VERSION_KEY] = CURRENT_VERSION
	myLogger:trace("[SETTINGS] Settings saved successfully")
	return true
end
function Settings.validateAndSanitize(settings)
	local validated = Utils.deepCopy(settings)
	local defaults = Settings.getDefaults()
	for key, defaultValue in pairs(defaults) do
		if validated[key] == nil then
			validated[key] = defaultValue
			myLogger:trace("[SETTINGS] Added missing setting: " .. key)
		end
	end
	local validSizes = {"1500", "2000", "3000", "4000", "5000", "6000", "original"}
	local sizeValid = false
	for _, size in ipairs(validSizes) do
		if validated.photoSize == size then
			sizeValid = true
			break
		end
	end
	if not sizeValid then
		validated.photoSize = defaults.photoSize
		myLogger:trace("[SETTINGS] Reset invalid photo size")
	end
	local quality = tonumber(validated.jpegQuality)
	if not quality or quality < 0.0 or quality > 1.0 then
		validated.jpegQuality = defaults.jpegQuality
		myLogger:trace("[SETTINGS] Reset invalid JPEG quality")
	end
	local limitKB = tonumber(validated.fileSizeLimitKB)
	if not limitKB or limitKB < 10 or limitKB > 10000 then
		validated.fileSizeLimitKB = defaults.fileSizeLimitKB
		myLogger:trace("[SETTINGS] Reset invalid file size limit")
	end
	local interval = tonumber(validated.scanInterval)
	if not interval or interval < 5 or interval > 300 then
		validated.scanInterval = defaults.scanInterval
		myLogger:trace("[SETTINGS] Reset invalid wait interval")
	end
	local maxPhotos = tonumber(validated.maxPhotosPerBatch)
	if not maxPhotos or maxPhotos < 1 or maxPhotos > 100 then
		validated.maxPhotosPerBatch = defaults.maxPhotosPerBatch
		myLogger:trace("[SETTINGS] Reset invalid max photos per batch")
	end
	local batchSize = tonumber(validated.batchSize)
	if not batchSize or batchSize < 1 or batchSize > 20 then
		validated.batchSize = defaults.batchSize
		myLogger:trace("[SETTINGS] Reset invalid batch size")
	end
	if not validated.outputFolder or validated.outputFolder == "" then
		validated.outputFolder = defaults.outputFolder
		myLogger:trace("[SETTINGS] Reset empty output folder")
	end
	if validated.scanMode ~= "all" and validated.scanMode ~= "selected" then
		validated.scanMode = defaults.scanMode
		myLogger:trace("[SETTINGS] Reset invalid scan mode")
	end
	if validated.scanMode == "selected" then
		if not validated.selectedFolder or validated.selectedFolder == "" then
			myLogger:trace("[SETTINGS] Warning: Selected folder mode but no folder specified")
		end
	end
	if validated.ftpEnabled then
		if not validated.ftpUsername or validated.ftpUsername == "" then
			myLogger:trace("[SETTINGS] Warning: FTP enabled but no username")
		end
		if not validated.ftpPassword or validated.ftpPassword == "" then
			myLogger:trace("[SETTINGS] Warning: FTP enabled but no password")
		end
	end
	return validated
end
function Settings.migrateSettings(settings, fromVersion)
	if fromVersion ~= CURRENT_VERSION then
		myLogger:trace("[SETTINGS] Migrated settings from " .. fromVersion .. " to " .. CURRENT_VERSION)
	end
	return settings
end
function Settings.reset()
	local prefs = LrPrefs.prefsForPlugin()
	prefs[PREFS_KEY] = nil
	prefs[VERSION_KEY] = nil
	myLogger:trace("[SETTINGS] Settings reset to defaults")
	return Settings.getDefaults()
end
function Settings.export()
	local settings = Settings.load()
	local exportSettings = Utils.deepCopy(settings)
	exportSettings.ftpPassword = "" -- Clear password
	exportSettings.windowPosition = nil -- Clear UI state
	exportSettings.lastUsed = nil
	return exportSettings
end
function Settings.import(importedSettings)
	if not importedSettings or type(importedSettings) ~= 'table' then
		myLogger:trace("[SETTINGS] Invalid settings for import")
		return false
	end
	local currentSettings = Settings.load()
	local mergedSettings = Utils.mergeTables(currentSettings, importedSettings)
	return Settings.save(mergedSettings)
end
function Settings.getSummary(settings)
	settings = settings or Settings.load()
	local summary = {}
	table.insert(summary, "Export: " .. settings.photoSize .. "px to " .. (settings.outputFolder or "Not set"))
	if settings.useFileSizeLimit then
		table.insert(summary, "Size limit: " .. settings.fileSizeLimitKB .. "KB")
	end
	if settings.applyPresets then
		table.insert(summary, "Presets: Apply from " .. settings.presetFolder)
	else
		table.insert(summary, "Presets: None")
	end
	table.insert(summary, "Wait between batches: " .. settings.scanInterval .. " seconds")
	if settings.ftpEnabled then
		table.insert(summary, "FTP: Enabled (" .. settings.ftpUsername .. "@" .. settings.ftpServer .. ")")
	else
		table.insert(summary, "FTP: Disabled")
	end
	return summary
end
function Settings.isValid(settings)
	settings = settings or Settings.load()
	if not settings.outputFolder or settings.outputFolder == "" then
		return false, "Output folder is required"
	end
	if not Utils.isDirectory(settings.outputFolder) then
		local success, error = Utils.ensureDirectory(settings.outputFolder)
		if not success then
			return false, "Cannot create output folder: " .. (error or "Unknown error")
		end
	end
	if settings.ftpEnabled then
		if not settings.ftpUsername or settings.ftpUsername == "" then
			return false, "FTP username is required when FTP is enabled"
		end
		if not settings.ftpPassword or settings.ftpPassword == "" then
			return false, "FTP password is required when FTP is enabled"
		end
	end
	return true, "Settings are valid"
end
return Settings