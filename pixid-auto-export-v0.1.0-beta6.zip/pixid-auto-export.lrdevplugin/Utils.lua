Utils.lua
Cross-platform utility functions for pixid Auto Export
Provides helper functions for:
- Operating system detection
- Path manipulation
- Home directory resolution
- Common formatting operations
Based on proven patterns from existing production plugin.
local LrSystemInfo = import 'LrSystemInfo'
local LrPathUtils = import 'LrPathUtils'
local Utils = {}
function Utils.getOS()
	local systemInfo = LrSystemInfo.summaryString()
	if string.find(systemInfo, "Windows") then
		return "Windows"
	elseif string.find(systemInfo, "Mac") then
		return "macOS"
	else
		return "Linux"
	end
end
function Utils.getHome()
	local LrPathUtils = import 'LrPathUtils'
	local osType = Utils.getOS()
	if osType == "Windows" then
		local userProfile = LrPathUtils.getStandardFilePath("home")
		return userProfile or "C:\\Users\\Public"
	else
		local homeDir = LrPathUtils.getStandardFilePath("home")
		return homeDir or "/Users"
	end
end
function Utils.getDefaultPicturesDir()
	local LrPathUtils = import 'LrPathUtils'
	local picturesDir = LrPathUtils.getStandardFilePath("pictures")
	if picturesDir then
		return picturesDir
	end
	local home = Utils.getHome()
	return LrPathUtils.child(home, "Pictures")
end
function Utils.formatFileSize(bytes)
	if not bytes or bytes == 0 then
		return "0 B"
	end
	local units = {"B", "KB", "MB", "GB", "TB"}
	local unitIndex = 1
	local size = bytes
	while size >= 1024 and unitIndex < #units do
		size = size / 1024
		unitIndex = unitIndex + 1
	end
	if unitIndex == 1 then
		return string.format("%d %s", size, units[unitIndex])
	else
		return string.format("%.1f %s", size, units[unitIndex])
	end
end
function Utils.formatDuration(seconds)
	if not seconds or seconds < 0 then
		return "0s"
	end
	local hours = math.floor(seconds / 3600)
	local minutes = math.floor((seconds % 3600) / 60)
	local secs = seconds % 60
	if hours > 0 then
		return string.format("%dh %dm %ds", hours, minutes, secs)
	elseif minutes > 0 then
		return string.format("%dm %ds", minutes, secs)
	else
		return string.format("%ds", secs)
	end
end
function Utils.formatTime(timestamp)
	if not timestamp then
		return "Unknown"
	end
	return os.date("%H:%M:%S", timestamp)
end
function Utils.formatDate(timestamp)
	if not timestamp then
		return "Unknown"
	end
	return os.date("%Y-%m-%d", timestamp)
end
function Utils.formatDateTime(timestamp)
	if not timestamp then
		return "Unknown"
	end
	return os.date("%Y-%m-%d %H:%M:%S", timestamp)
end
function Utils.isDirectory(path)
	if not path or path == "" then
		return false
	end
	local LrFileUtils = import 'LrFileUtils'
	return LrFileUtils.exists(path) == 'directory'
end
function Utils.isFile(path)
	if not path or path == "" then
		return false
	end
	local LrFileUtils = import 'LrFileUtils'
	return LrFileUtils.exists(path) == 'file'
end
function Utils.ensureDirectory(path)
	if not path or path == "" then
		return false, "Invalid path"
	end
	if Utils.isDirectory(path) then
		return true
	end
	local LrFileUtils = import 'LrFileUtils'
	local success, error = LrFileUtils.createAllDirectories(path)
	if success then
		return true
	else
		return false, error or "Failed to create directory"
	end
end
function Utils.generateUniqueFilename(basePath, baseName, extension)
	local fullPath = LrPathUtils.child(basePath, baseName .. extension)
	if not Utils.isFile(fullPath) then
		return fullPath, baseName .. extension
	end
	local counter = 1
	repeat
		local numberedName = baseName .. "_" .. counter
		fullPath = LrPathUtils.child(basePath, numberedName .. extension)
		counter = counter + 1
	until not Utils.isFile(fullPath)
	return fullPath, LrPathUtils.leafName(fullPath)
end
function Utils.getRatingDescription(rating)
	local descriptions = {
		[0] = "Unprocessed",
		[1] = "Presets Applied",
		[2] = "Exported",
		[3] = "Uploaded",
		[4] = "Custom Rating 4",
		[5] = "Custom Rating 5"
	}
	return descriptions[rating] or ("Rating " .. tostring(rating))
end
function Utils.isValidEmail(email)
	if not email or email == "" then
		return false
	end
	return string.match(email, "^[%w%._%+-]+@[%w%._%+-]+%.%a+$") ~= nil
end
function Utils.truncateString(str, maxLength)
	if not str then
		return ""
	end
	if string.len(str) <= maxLength then
		return str
	end
	return string.sub(str, 1, maxLength - 3) .. "..."
end
function Utils.deepCopy(original)
	if type(original) ~= 'table' then
		return original
	end
	local copy = {}
	for key, value in pairs(original) do
		copy[Utils.deepCopy(key)] = Utils.deepCopy(value)
	end
	return copy
end
function Utils.mergeTables(table1, table2)
	local result = Utils.deepCopy(table1)
	if type(table2) == 'table' then
		for key, value in pairs(table2) do
			result[key] = value
		end
	end
	return result
end
function Utils.tableToString(tbl, indent)
	if type(tbl) ~= 'table' then
		return tostring(tbl)
	end
	indent = indent or 0
	local indentStr = string.rep("  ", indent)
	local result = "{\n"
	for key, value in pairs(tbl) do
		result = result .. indentStr .. "  " .. tostring(key) .. " = "
		if type(value) == 'table' then
			result = result .. Utils.tableToString(value, indent + 1)
		elseif type(value) == 'string' then
			result = result .. '"' .. value .. '"'
		else
			result = result .. tostring(value)
		end
		result = result .. ",\n"
	end
	result = result .. indentStr .. "}"
	return result
end
return Utils