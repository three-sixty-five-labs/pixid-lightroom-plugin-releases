# pixid Auto Export - Universal Photo Processing

A revamped Lightroom plugin that automatically detects, processes, and exports photos from your entire catalog with zero configuration required.

## Key Features

✅ **Universal Detection**: Automatically finds ALL new photos in catalog (tethering + auto-import + manual import)  
✅ **Zero Configuration**: No folder selection needed - monitors entire catalog  
✅ **Rating-Based Processing**: Uses rating system (0→1→2→3) to track processing stages  
✅ **Automatic Presets**: Applies develop presets from Favorites folder  
✅ **Flexible Export**: Local JPEG export with configurable size and quality  
✅ **Optional FTP**: Direct upload to pixid FTP server  
✅ **Background Processing**: Runs without blocking Lightroom operations  

## Installation

1. Copy the `pixid-auto-export.lrdevplugin` folder to your Lightroom plugins directory
2. In Lightroom: `File > Plug-in Manager` (or `Ctrl+Alt+Shift+,` / `Cmd+Option+Shift+,`)
3. Click "Add" and select the plugin folder
4. Plugin should appear as "pixid Auto Export" in the list

## Usage

### Access the Plugin
`File > Plug-in Extras > pixid Auto Export Console`

### Basic Setup
1. **Set Output Folder**: Choose where exported JPEGs will be saved
2. **Choose Photo Size**: 1500px to 6000px or Original
3. **Configure Presets**: Enable to apply presets from Favorites folder automatically
4. **Set Scan Interval**: How often to check for new photos (default: 30 seconds)

### Optional FTP Setup
1. Check "Enable FTP upload to pixid"  
2. Enter your pixid FTP username and password
3. Photos will upload automatically after local export

### Start Processing
- **Start Auto-Processing**: Runs continuously in background
- **Process Once Now**: Process current unprocessed photos immediately
- **Stop Processing**: Stop background monitoring

## How It Works

### Rating System
- **Rating 0**: New unprocessed photos (automatically detected)
- **Rating 1**: Presets applied successfully
- **Rating 2**: Exported to local folder
- **Rating 3**: Uploaded to FTP (if enabled)

### Processing Pipeline
1. **Universal Scan**: Check ALL catalog folders for rating=0 photos
2. **Apply Presets**: Apply all presets from Favorites folder
3. **Local Export**: Create JPEG in output folder with chosen settings
4. **Optional Upload**: FTP to pixid server (if enabled)
5. **Update Rating**: Progress from 0→1→2→3 tracking each stage

### Universal Detection
- Monitors **entire catalog** automatically
- Works with **tethered shooting**
- Handles **auto-import** folders  
- Processes **manual imports**
- **No folder selection** required

## Architecture

### Core Modules
- **`Info.lua`**: Plugin manifest and registration
- **`AutoExportManager.lua`**: Main UI and control logic
- **`CatalogMonitor.lua`**: Universal photo detection system
- **`PhotoProcessor.lua`**: Core processing engine (presets + export + upload)
- **`Settings.lua`**: Configuration persistence
- **`Utils.lua`**: Cross-platform utilities

### Global State Management
The plugin maintains persistent state across dialog sessions using `_G.pixidAutoExportState`:
- Processing status and statistics
- Background task coordination
- Settings preservation

## Workflow Benefits

### vs. Folder-Specific Plugins
- ✅ **No Setup Required**: No folder selection needed
- ✅ **Catches Everything**: Won't miss photos from different sources
- ✅ **Set and Forget**: Universal detection works automatically

### vs. Publish Services
- ✅ **No Manual Collection Management**: No dragging photos to collections
- ✅ **Immediate Processing**: Automatic detection of new photos
- ✅ **Local Export First**: Separates export from upload concerns

### Camera → Lightroom → Export → Upload Workflow
1. **Camera**: Tethered or memory card import
2. **Lightroom**: Photos appear in catalog (any method)
3. **Export**: Plugin automatically detects and exports
4. **Upload**: Separate uploader component or direct FTP

## Settings

### Export Settings
- **Output Folder**: Where JPEGs are saved
- **Photo Size**: 1500px, 2000px, 3000px, 4000px, 5000px, 6000px, or Original
- **Apply Presets**: Use all presets from Favorites folder
- **File Size Limit**: Optional JPEG compression to target KB size

### Processing Settings  
- **Scan Interval**: 5-300 seconds between catalog scans
- **Universal Detection**: Automatic - no configuration needed

### FTP Settings (Optional)
- **Server**: ftp.pixid.app (fixed)
- **Username**: Your pixid FTP username  
- **Password**: Your pixid FTP password

## Troubleshooting

### Plugin Not Appearing
- Check that folder is named `pixid-auto-export.lrdevplugin`
- Verify all `.lua` files are present
- Restart Lightroom after installation

### No Photos Being Processed
- Check that photos have rating = 0 (unrated)
- Verify output folder exists and is writable
- Check that presets exist in Favorites folder (if enabled)

### FTP Upload Issues
- Verify username/password are correct
- Check internet connection
- Try processing without FTP first to isolate issue

### Performance with Large Catalogs
- Increase scan interval for less frequent checks
- Process photos in smaller batches manually
- Consider rating processed photos to exclude from future scans

## Development

Built with Lightroom SDK 5.0+ using proven patterns from production auto-export plugins. Designed for universal photo detection with zero-configuration workflow.

### Version History
- v1.0.0: Initial implementation with universal detection and optional FTP upload

### Support
For issues or questions, check the documentation in the `docs/` folder of the repository.