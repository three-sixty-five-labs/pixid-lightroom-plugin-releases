--[[----------------------------------------------------------------------------

Settings.lua
Configuration persistence for pixid Auto Export

Handles loading, saving, and validation of plugin settings using Lightroom's
preferences system. Provides default values and migration support.

------------------------------------------------------------------------------]]

local LrPrefs = import 'LrPrefs'
local LrLogger = import 'LrLogger'

local Utils = require 'Utils'

local myLogger = LrLogger('Settings')
myLogger:enable('print')

local Settings = {}

-- Key for storing settings in Lightroom preferences
local PREFS_KEY = "pixidAutoExportSettings"
local VERSION_KEY = "pixidAutoExportVersion"
local CURRENT_VERSION = "1.0.0"

-- Default settings with sensible values
function Settings.getDefaults()
	return {
		-- Export Settings
		outputFolder = Utils.getDefaultPicturesDir(),
		photoSize = "2000",
		jpegQuality = 1.0,
		useFileSizeLimit = false,
		fileSizeLimitKB = 750,
		
		-- Processing Settings
		applyPresets = true,
		presetFolder = "Favorites",
		
		-- Auto-Processing Settings
		scanInterval = 30, -- seconds wait between batches
		autoStartOnLightroom = false,
		maxPhotosPerBatch = 10,
		scanMode = "all", -- "all" or "selected"
		selectedFolder = "",
		selectedFolderName = "", -- Will default to first folder
		
		-- Advanced Reliability Settings (always enabled)
		batchSize = 5,                -- Photos per batch
		showDetailedProgress = true,  -- Always show detailed progress
		
		-- FTP Settings
		ftpEnabled = false,
		ftpUsername = "",
		ftpPassword = "",
		ftpServer = "ftp.pixid.app",
		ftpPort = 21,
		ftpPath = "/",
		
		-- Advanced Options
		deleteAfterUpload = false,
		preserveOriginalName = true,
		logLevel = "info",
		
		-- UI State
		windowPosition = nil,
		lastUsed = os.time(),
	}
end

-- Load settings from Lightroom preferences
function Settings.load()
	local prefs = LrPrefs.prefsForPlugin()
	local savedSettings = prefs[PREFS_KEY] or {}
	local savedVersion = prefs[VERSION_KEY] or "0.0.0"
	
	myLogger:trace("[SETTINGS] Loading settings (version: " .. savedVersion .. ")")
	
	-- Start with defaults and merge saved settings
	local settings = Utils.mergeTables(Settings.getDefaults(), savedSettings)
	
	-- Perform version migration if needed
	settings = Settings.migrateSettings(settings, savedVersion)
	
	-- Validate and sanitize loaded settings
	settings = Settings.validateAndSanitize(settings)
	
	myLogger:trace("[SETTINGS] Settings loaded successfully")
	return settings
end

-- Save settings to Lightroom preferences
function Settings.save(settings)
	if not settings then
		myLogger:trace("[SETTINGS] No settings to save")
		return false
	end
	
	-- Validate before saving
	local validatedSettings = Settings.validateAndSanitize(settings)
	
	-- Update last used timestamp
	validatedSettings.lastUsed = os.time()
	
	local prefs = LrPrefs.prefsForPlugin()
	prefs[PREFS_KEY] = validatedSettings
	prefs[VERSION_KEY] = CURRENT_VERSION
	
	myLogger:trace("[SETTINGS] Settings saved successfully")
	return true
end

-- Validate and sanitize settings
function Settings.validateAndSanitize(settings)
	local validated = Utils.deepCopy(settings)
	local defaults = Settings.getDefaults()
	
	-- Ensure all required keys exist
	for key, defaultValue in pairs(defaults) do
		if validated[key] == nil then
			validated[key] = defaultValue
			myLogger:trace("[SETTINGS] Added missing setting: " .. key)
		end
	end
	
	-- Validate specific settings
	
	-- Photo size validation
	local validSizes = {"1500", "2000", "3000", "4000", "5000", "6000", "original"}
	local sizeValid = false
	for _, size in ipairs(validSizes) do
		if validated.photoSize == size then
			sizeValid = true
			break
		end
	end
	if not sizeValid then
		validated.photoSize = defaults.photoSize
		myLogger:trace("[SETTINGS] Reset invalid photo size")
	end
	
	-- JPEG quality validation (0.0 to 1.0)
	local quality = tonumber(validated.jpegQuality)
	if not quality or quality < 0.0 or quality > 1.0 then
		validated.jpegQuality = defaults.jpegQuality
		myLogger:trace("[SETTINGS] Reset invalid JPEG quality")
	end
	
	-- File size limit validation
	local limitKB = tonumber(validated.fileSizeLimitKB)
	if not limitKB or limitKB < 10 or limitKB > 10000 then
		validated.fileSizeLimitKB = defaults.fileSizeLimitKB
		myLogger:trace("[SETTINGS] Reset invalid file size limit")
	end
	
	-- Wait interval validation (5 to 300 seconds)
	local interval = tonumber(validated.scanInterval)
	if not interval or interval < 5 or interval > 300 then
		validated.scanInterval = defaults.scanInterval
		myLogger:trace("[SETTINGS] Reset invalid wait interval")
	end
	
	-- Max photos per batch validation (1 to 100)
	local maxPhotos = tonumber(validated.maxPhotosPerBatch)
	if not maxPhotos or maxPhotos < 1 or maxPhotos > 100 then
		validated.maxPhotosPerBatch = defaults.maxPhotosPerBatch
		myLogger:trace("[SETTINGS] Reset invalid max photos per batch")
	end
	
	-- Advanced reliability settings validation
	local batchSize = tonumber(validated.batchSize)
	if not batchSize or batchSize < 1 or batchSize > 20 then
		validated.batchSize = defaults.batchSize
		myLogger:trace("[SETTINGS] Reset invalid batch size")
	end
	
	
	-- Output folder validation
	if not validated.outputFolder or validated.outputFolder == "" then
		validated.outputFolder = defaults.outputFolder
		myLogger:trace("[SETTINGS] Reset empty output folder")
	end
	
	-- Scan mode validation
	if validated.scanMode ~= "all" and validated.scanMode ~= "selected" then
		validated.scanMode = defaults.scanMode
		myLogger:trace("[SETTINGS] Reset invalid scan mode")
	end
	
	-- Selected folder validation (when in selected mode)
	if validated.scanMode == "selected" then
		if not validated.selectedFolder or validated.selectedFolder == "" then
			myLogger:trace("[SETTINGS] Warning: Selected folder mode but no folder specified")
		end
	end
	
	-- FTP settings validation
	if validated.ftpEnabled then
		if not validated.ftpUsername or validated.ftpUsername == "" then
			myLogger:trace("[SETTINGS] Warning: FTP enabled but no username")
		end
		if not validated.ftpPassword or validated.ftpPassword == "" then
			myLogger:trace("[SETTINGS] Warning: FTP enabled but no password")
		end
	end
	
	return validated
end

-- Migrate settings from older versions
function Settings.migrateSettings(settings, fromVersion)
	-- No migrations needed yet for v1.0.0
	-- Future versions can add migration logic here
	
	if fromVersion ~= CURRENT_VERSION then
		myLogger:trace("[SETTINGS] Migrated settings from " .. fromVersion .. " to " .. CURRENT_VERSION)
	end
	
	return settings
end

-- Reset settings to defaults
function Settings.reset()
	local prefs = LrPrefs.prefsForPlugin()
	prefs[PREFS_KEY] = nil
	prefs[VERSION_KEY] = nil
	
	myLogger:trace("[SETTINGS] Settings reset to defaults")
	return Settings.getDefaults()
end

-- Export settings to a table (for backup/sharing)
function Settings.export()
	local settings = Settings.load()
	
	-- Remove sensitive data for export
	local exportSettings = Utils.deepCopy(settings)
	exportSettings.ftpPassword = "" -- Clear password
	exportSettings.windowPosition = nil -- Clear UI state
	exportSettings.lastUsed = nil
	
	return exportSettings
end

-- Import settings from a table
function Settings.import(importedSettings)
	if not importedSettings or type(importedSettings) ~= 'table' then
		myLogger:trace("[SETTINGS] Invalid settings for import")
		return false
	end
	
	-- Merge with current settings (to preserve passwords, etc.)
	local currentSettings = Settings.load()
	local mergedSettings = Utils.mergeTables(currentSettings, importedSettings)
	
	-- Save the merged settings
	return Settings.save(mergedSettings)
end

-- Get a summary of current settings for display
function Settings.getSummary(settings)
	settings = settings or Settings.load()
	
	local summary = {}
	
	-- Export settings
	table.insert(summary, "Export: " .. settings.photoSize .. "px to " .. (settings.outputFolder or "Not set"))
	
	if settings.useFileSizeLimit then
		table.insert(summary, "Size limit: " .. settings.fileSizeLimitKB .. "KB")
	end
	
	-- Processing settings
	if settings.applyPresets then
		table.insert(summary, "Presets: Apply from " .. settings.presetFolder)
	else
		table.insert(summary, "Presets: None")
	end
	
	-- Auto-processing
	table.insert(summary, "Wait between batches: " .. settings.scanInterval .. " seconds")
	
	-- FTP settings
	if settings.ftpEnabled then
		table.insert(summary, "FTP: Enabled (" .. settings.ftpUsername .. "@" .. settings.ftpServer .. ")")
	else
		table.insert(summary, "FTP: Disabled")
	end
	
	return summary
end

-- Check if settings are valid for processing
function Settings.isValid(settings)
	settings = settings or Settings.load()
	
	-- Required fields
	if not settings.outputFolder or settings.outputFolder == "" then
		return false, "Output folder is required"
	end
	
	-- Check if output folder exists or can be created
	if not Utils.isDirectory(settings.outputFolder) then
		local success, error = Utils.ensureDirectory(settings.outputFolder)
		if not success then
			return false, "Cannot create output folder: " .. (error or "Unknown error")
		end
	end
	
	-- FTP validation if enabled
	if settings.ftpEnabled then
		if not settings.ftpUsername or settings.ftpUsername == "" then
			return false, "FTP username is required when FTP is enabled"
		end
		if not settings.ftpPassword or settings.ftpPassword == "" then
			return false, "FTP password is required when FTP is enabled"
		end
	end
	
	return true, "Settings are valid"
end

return Settings