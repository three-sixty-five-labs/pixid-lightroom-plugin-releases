--[[----------------------------------------------------------------------------

PhotoProcessor.lua
Core processing engine for pixid Auto Export

Simple version that follows the exact pattern from the working plugin.

------------------------------------------------------------------------------]]

local LrApplication = import 'LrApplication'
local LrExportSession = import 'LrExportSession'
local LrTasks = import 'LrTasks'
local LrDialogs = import 'LrDialogs'
local LrPathUtils = import 'LrPathUtils'
local LrFileUtils = import 'LrFileUtils'
local LrFtp = import 'LrFtp'
local LrErrors = import 'LrErrors'
local LrLogger = import 'LrLogger'
local LrFunctionContext = import 'LrFunctionContext'

local myLogger = LrLogger('PhotoProcessor')
myLogger:enable('print')

local PhotoProcessor = {}

-- Simple processing function that follows the working plugin's exact pattern
function PhotoProcessor.processPhotos(photos, outputFolder, photoSize, ftpInfo, extra)
	if #photos == 0 then
		myLogger:trace("[PROCESSOR] No photos to process")
		return
	end
	
	myLogger:trace("[PROCESSOR] Starting processing of " .. #photos .. " photos")
	
	local processedCount = 0
	local ftpErrorCount = 0
	
	-- Use the exact same pattern as the working plugin
	LrFunctionContext.callWithContext("export", function(exportContext)
		local progressScope = LrDialogs.showModalProgressDialog({
			title = "pixid Auto Export",
			caption = "starting ...",
			cannotCancel = false,
			functionContext = exportContext
		})

		-- Build export settings (simplified version)
		local exportSettings = {
			LR_collisionHandling = "rename",
			LR_export_bitDepth = "8",
			LR_export_colorSpace = "sRGB",
			LR_export_destinationPathPrefix = outputFolder,
			LR_export_destinationType = "specificFolder",
			LR_export_useSubfolder = false,
			LR_format = "JPEG",
			LR_jpeg_quality = 1,
			LR_minimizeEmbeddedMetadata = true,
			LR_outputSharpeningOn = false,
			LR_reimportExportedPhoto = false,
			LR_renamingTokensOn = true,
			LR_size_doNotEnlarge = true,
			LR_size_units = "pixels",
			LR_tokens = "{{image_name}}",
			LR_useWatermark = false,
			LR_jpeg_useLimitSize = false,
			LR_jpeg_limitSize = null,
		}

		-- Size settings
		if photoSize ~= "original" then
			exportSettings['LR_size_doConstrain'] = true
			exportSettings['LR_size_maxHeight'] = tonumber(photoSize)
			exportSettings['LR_size_maxWidth'] = tonumber(photoSize)
			exportSettings['LR_size_resolution'] = 300
		end

		-- File size limit - exactly like working plugin
		if extra and extra['useFileSizeLimit'] then
			exportSettings['LR_jpeg_useLimitSize'] = true
			exportSettings['LR_jpeg_limitSize'] = tonumber(extra['fileSizeLimit'])
		end

		local exportSession = LrExportSession({
			photosToExport = photos,
			exportSettings = exportSettings, 
		})

		local numPhotos = exportSession:countRenditions()
		local renditionParams = {
			progressScope = progressScope,
			renderProgressPortion = 1,
			stopIfCanceled = true,
		}

		-- FTP setup if needed - exactly like working plugin
		local ftpInstance
		if ftpInfo and ftpInfo['isEnabled'] then
			local ftpPreset = {
				passive = "none",
				path = "/",
				port = 21,
				protocol = "ftp",
				server = "ftp.pixid.app",
				username = ftpInfo['ftpUsername'],
				password = ftpInfo['ftpPassword']
			}

			ftpInstance = LrFtp.create(ftpPreset, true)
			
			if not ftpInstance then -- This really shouldn't ever happen.
				myLogger:trace("[FTP] Failed to create FTP instance")
			end		
		end

		-- Apply presets if requested (simplified)
		if extra and extra['presetsInFavoriteIsApplied'] then
			local catalog = LrApplication.activeCatalog()
			local presetFolders = LrApplication.developPresetFolders()
			if #presetFolders > 0 then
				local presetFolder = presetFolders[1]
				local presets = presetFolder:getDevelopPresets()
				
				for i, photo in pairs(photos) do
					progressScope:setCaption("Applying presets (" .. i .. "/" .. numPhotos .. ")")
					progressScope:setPortionComplete(i - 1, numPhotos)

					catalog:withWriteAccessDo("Applying presets", function(context)
						for _, preset in pairs(presets) do
							photo:applyDevelopPreset(preset)
						end
						photo:setRawMetadata("rating", 1)
					end)
				end
			end
		end

		-- Process renditions - THE CRITICAL PART
		for i, rendition in exportSession:renditions(renditionParams) do
			if progressScope:isCanceled() then break end

			local progressCaption = "Exporting " .. rendition.photo:getFormattedMetadata("fileName") .. " (" .. i .. "/" .. numPhotos .. ")"
			progressScope:setPortionComplete(i - 1, numPhotos)
			progressScope:setCaption(progressCaption)

			-- This should work with proper context
			local success, pathOrMessage = rendition:waitForRender()
		
			if progressScope:isCanceled() then break end
			
			-- Update rating
			local catalog = LrApplication.activeCatalog()
			catalog:withWriteAccessDo("processing", function(context)	
				rendition.photo:setRawMetadata("rating", 2)
			end)
			processedCount = processedCount + 1

			-- FTP upload if enabled - exactly like working plugin
			if success and ftpInstance then
				local filename = LrPathUtils.leafName(pathOrMessage)		
				local ftpSuccess = ftpInstance:putFile(pathOrMessage, filename)
				
				if ftpSuccess then
					catalog:withWriteAccessDo("processing", function(context)	
						rendition.photo:setRawMetadata("rating", 3)
					end)
				else
					-- FTP upload failed - show bezel and count error
					ftpErrorCount = ftpErrorCount + 1
					LrDialogs.showBezel("FTP upload failed: " .. filename)
					myLogger:trace("[FTP] Failed to upload " .. filename)
				end
			end

			if progressScope:isCanceled() then break end
		end

		if LrTasks.canYield() then
			LrTasks.yield()
		end

		if ftpInstance then
			ftpInstance:disconnect()
		end
		
		progressScope:done()
	end)

	if LrTasks.canYield() then
		LrTasks.yield()
	end

	myLogger:trace("[PROCESSOR] Processing complete - " .. processedCount .. " processed, " .. ftpErrorCount .. " FTP errors")
	
	return {
		processed = processedCount,
		ftpErrors = ftpErrorCount
	}
end

return PhotoProcessor